package Swing_Files;

public class Testing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int a = 40;
		
		//double check = a

	}

}
