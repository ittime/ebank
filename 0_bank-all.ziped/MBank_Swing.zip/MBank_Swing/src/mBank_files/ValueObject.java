package mBank_files;

public abstract class ValueObject 
{
	public ValueObject () {}
	
}
