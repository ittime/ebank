package threads;

public abstract class DepositCheckThread implements Runnable

{
	protected Thread t;
	
	public DepositCheckThread(){}
	
}
