package threads;

public abstract class indexUpdateThread implements Runnable
{
	protected Thread t;
	
	public indexUpdateThread(){}
	

}
