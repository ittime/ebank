package valueObject;

public abstract class ValueObject 
{
	public ValueObject () {}
	
}
